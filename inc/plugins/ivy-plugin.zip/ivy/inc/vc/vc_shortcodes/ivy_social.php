<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 *
 */
function ivy_social_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Social", 'ivy'),
            "base" => "ivy_social_shortcode",
            'description' => esc_html__('Create social link', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

            array(
                'type' => 'dropdown',
                'heading' => esc_html__('Position block', 'ivy'),
                'param_name' => 'position',
                'description' => esc_html__('', 'ivy'),
                'value' => array(
                    'center' => 'center',
                    'left' => 'left',
                    'right' => 'right',
                ),
            ),

            array(
                'type' => 'css_editor',
                'heading' => esc_html__('Css', 'ivy'),
                'param_name' => 'css',
                'group' => esc_html__('Design options', 'ivy'),
            ),

            array(
                    'type' => 'vc_link',
                'heading' => esc_html__('URL Link Instagram', 'ivy'),
                'param_name' => 'url_instagram',
                'description' => esc_html__('', 'ivy'),
            ),
            array(
                'type' => 'vc_link',
                'heading' => esc_html__('URL Link Facebook', 'ivy'),
                'param_name' => 'url_facebook',
                'description' => esc_html__('', 'ivy'),
            ),
            array(
                'type' => 'vc_link',
                'heading' => esc_html__('URL Link Twitter', 'ivy'),
                'param_name' => 'url_twitter',
                'description' => esc_html__('', 'ivy'),
            ),
            array(
                'type' => 'vc_link',
                'heading' => esc_html__('URL Link Google+', 'ivy'),
                'param_name' => 'url_google',
                'description' => esc_html__('', 'ivy'),
            ),

            )
        )
    );

}

add_action('vc_before_init', 'ivy_social_fn_vc');


// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCode')){
    class WPBakeryShortCode_ivy_social_shortcode extends WPBakeryShortCode {

    }
}