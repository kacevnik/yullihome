<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_title_page_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Title page", 'ivy'),
            "base" => "ivy_title_page_shortcode",
            'description' => esc_html__('Title page', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title text', 'ivy' ),
                    'param_name' => 'title_text',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Subtitle text', 'ivy' ),
                    'param_name' => 'subtitle_text',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Text Align', 'ivy'),
                    'param_name' => 'text_align',
                    'value' => array(
                        'center' => 'center',
                        'Left' => 'left',
                        'right' => 'right',
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Float', 'ivy'),
                    'param_name' => 'float',
                    'value' => array(
                        'none' => 'none',
                        'left' => 'left',
                        'right' => 'right',
                    ),
                ),
                array(
                        'type' => 'css_editor',
                        'heading' => esc_html__('Css', 'soliaris'),
                        'param_name' => 'css',
                        'group' => esc_html__('Design options', 'soliaris'),
                ),
            )
        )
    );

}

add_action('vc_before_init', 'ivy_title_page_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_title_page_shortcode extends WPBakeryShortCode
    {
    }
}