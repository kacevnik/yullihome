<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_about_block_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("About Block", 'ivy'),
            "base" => "ivy_about_block_shortcode",
            'description' => esc_html__('About Block', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title text', 'ivy' ),
                    'param_name' => 'title_text',
                ),
                array(
                    'type' => 'textarea_html',
                    'heading' => esc_html__( 'Description', 'ivy' ),
                    'param_name' => 'desc',
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image Background', 'ivy'),
                    'param_name' => 'image_back',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image', 'ivy'),
                    'param_name' => 'image',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image Border', 'ivy'),
                    'param_name' => 'image_border',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
            )
        )
    );
}

add_action('vc_before_init', 'ivy_about_block_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_about_block_shortcode extends WPBakeryShortCode
    {
    }
}