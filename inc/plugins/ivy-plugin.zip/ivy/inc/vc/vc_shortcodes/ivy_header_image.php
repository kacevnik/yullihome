<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_header_image_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Header Image", 'ivy'),
            "base" => "ivy_header_image_shortcode",
            'description' => esc_html__('Theme header image', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title text', 'ivy' ),
                    'param_name' => 'title_text',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Width text type', 'ivy' ),
                    'param_name' => 'width_text',
                    'value' => array(
                        'Default' => 'default',
                        'Full width container' => 'full',
                    ),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image Background', 'ivy'),
                    'param_name' => 'image_header',
                    'value' => '',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image Border', 'ivy'),
                    'param_name' => 'image_header_border',
                    'value' => '',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
            )
        )
    );

}

add_action('vc_before_init', 'ivy_header_image_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_header_image_shortcode extends WPBakeryShortCode
    {
    }
}