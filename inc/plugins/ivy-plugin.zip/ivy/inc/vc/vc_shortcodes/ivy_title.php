<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_title_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Title", 'ivy'),
            "base" => "ivy_title_shortcode",
            'description' => esc_html__('Theme title', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Title text', 'ivy' ),
                    'param_name' => 'title_text',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Subtitle text', 'ivy' ),
                    'param_name' => 'subtitle_text',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

            )
        )
    );

}

add_action('vc_before_init', 'ivy_title_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_title_shortcode extends WPBakeryShortCode
    {
    }
}