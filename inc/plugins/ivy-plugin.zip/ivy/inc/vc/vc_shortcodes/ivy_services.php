<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 *
 */
function ivy_services_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Services", 'ivy'),
            "base" => "ivy_services_shortcode",
            'description' => esc_html__('Create service', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'ivy' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ivy' ),
                    ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Css', 'ivy'),
                    'param_name' => 'css',
                    'group' => esc_html__('Design options', 'ivy'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image', 'ivy'),
                    'param_name' => 'image',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Position image', 'ivy'),
                    'param_name' => 'position',
                    'description' => esc_html__('', 'ivy'),
                    'value' => array(
                        'left' => 'left',
                        'right' => 'right',
                    ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Top text', 'ivy'),
                    'param_name' => 'top_text',
                    'admin_label' => true,
                    'description' => esc_html__('', 'ivy'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Title', 'ivy'),
                    'param_name' => 'title',
                    'admin_label' => true,
                    'description' => esc_html__('', 'ivy'),
                ),

                array(
                    'type' => 'textarea_html',
                    'heading' => esc_html__('Description', 'ivy'),
                    'param_name' => 'desc',
                    'description' => esc_html__('', 'ivy'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Letter', 'ivy'),
                    'param_name' => 'letter',
                    'description' => esc_html__('Enter one letter! Example: B', 'ivy'),
                ),
            )
        )
    );

}

add_action('vc_before_init', 'ivy_services_fn_vc');


// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCodesContainer')){
    class WPBakeryShortCode_ivy_services_shortcode extends WPBakeryShortCodesContainer {

    }
}