<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 *
 */
function ivy_we_offer_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("We Offer", 'ivy'),
            "base" => "ivy_we_offer_shortcode",
            'description' => esc_html__('Create block', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'ivy' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ivy' ),
                    ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Css', 'ivy'),
                    'param_name' => 'css',
                    'group' => esc_html__('Design options', 'ivy'),
                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Icon', 'ivy'),
                    'param_name' => 'icon',
                    'description' => esc_html__('Select icon from media library.', 'ivy'),
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Top text', 'ivy'),
                    'param_name' => 'top_text',
                    'admin_label' => true,
                    'description' => esc_html__('', 'ivy'),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__('Title', 'ivy'),
                    'param_name' => 'title',
                    'admin_label' => true,
                    'description' => esc_html__('', 'ivy'),
                ),

                array(
                    'type' => 'textarea_html',
                    'heading' => esc_html__('Description', 'ivy'),
                    'param_name' => 'desc',
                    'description' => esc_html__('', 'ivy'),
                ),

            )
        )
    );

}

add_action('vc_before_init', 'ivy_we_offer_fn_vc');


// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_we_offer_shortcode extends WPBakeryShortCode
    {
    }
}