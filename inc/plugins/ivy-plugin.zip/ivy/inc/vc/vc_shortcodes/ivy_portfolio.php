<?php
if ( ! defined( 'ABSPATH' ) ) { die( '-1' ); }

function ivy_portfolio_fn_vc() {
	$cats_list=array();
	$portfolio_cats = get_terms(array('taxonomy'=>'portfolio_cats', 'orderby' => 'ID'));
	if (!empty($portfolio_cats) && !is_wp_error($portfolio_cats)) {
		foreach( $portfolio_cats as $cat ){
			$cats_list[$cat->name]=$cat->term_id;
		}
	}

	vc_map(

		array(
			"icon" => 'allure-vc-block',
			"name" => esc_html__("Portfolio", 'ivy'),
			"base" => "ivy_portfolio_shortcode",
			'description' => esc_html__( 'Portfolio items', 'ivy' ),
			"category" => esc_html__('IVY', 'ivy'),
			"params" => array(

				array(
					'type'        => 'ivy_vc_multiselect',
					'heading'     => 'Select Categories',
					'param_name'  => 'cats',
					'value'         => $cats_list,
					'description' => esc_html__('','ivy'),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-1',
                            'type-2',
                            'type-3',
                            'type-4',
                            'type-6',
                        )
                    ),
				),

                array(
                    "type"          => "dropdown",
                    "heading"       => __( "All Categories", 'ivy' ),
                    'description' => esc_html__('Hide or show "All" categories','ivy'),
                    'value' => array(
                        'Show' => 'show',
                        'Hide' => 'hide',
                    ),
                    "param_name"    => "all_check",
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-1',
                            'type-2',
                            'type-3',
                            'type-4',
                            'type-6',
                        )
                    ),
                ),

                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Text Align Categories', 'ivy'),
                    'param_name' => 'text_align',
                    'value' => array(
                        'center' => 'center',
                        'Left' => 'left',
                        'right' => 'right',
                    ),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-1',
                            'type-2',
                            'type-3',
                            'type-4',
                            'type-6',
                        )
                    ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__('Float Categories', 'ivy'),
                    'param_name' => 'float',
                    'value' => array(
                        'none' => 'none',
                        'left' => 'left',
                        'right' => 'right',
                    ),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-1',
                            'type-2',
                            'type-3',
                            'type-4',
                            'type-6',
                        )
                    ),
                ),

                array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__( "Click on image", 'ivy' ),
                    'description' => esc_html__('Select your type','ivy'),
                    'value' => array(
                        'Open popup with photo, photo gallery' =>  'type-one',
                        'Open new page with detail portfolio'  =>  'type-two',
                    ),
                    "param_name"    => "type_click",
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-1',
                            'type-3',
                            'type-4',
                        )
                    ),
                ),

                array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__( "Type Portfolio", 'ivy' ),
                    'description' => esc_html__('Select your type portfolio','ivy'),
                    'value' => array(
                        'Type 1' =>  'type-1',
                        'Type 2' =>  'type-2',
                        'Type 3' =>  'type-3',
                        'Type 4' =>  'type-4',
                        'Type 5' =>  'type-5',
                        'Type 6' =>  'type-6',
                    ),
                    "param_name"    => "type_portfolio",
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Select Category','ivy'),
                    'param_name'  => 'cat_one',
                    'value'       => $cats_list,
                    'description' => esc_html__('Select one category or all categories','ivy'),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-5',
                        )
                    ),
                ),

                array(
                    'type'        => 'checkbox',
                    'heading'     => esc_html__('Output all categories','ivy'),
                    'param_name'  => 'enab_all',
                    'value'       => array(
                        'All'   =>  'all',
                    ),
                    'description' => esc_html__('','ivy'),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-5',
                        )
                    ),
                ),

                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__('Full width or container','ivy'),
                    'param_name'  => 'width_content',
                    'value'       => array(
                        'container'   =>  'container',
                        'Full width'   =>  'container-fluid',
                    ),
                    'description' => esc_html__('','ivy'),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-3',
                        )
                    ),
                ),

                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__('Default letter','ivy'),
                    'param_name'  => 'default_letter',
                    'description' => esc_html__('Enter default letter on your portfolio.','ivy'),
                    'dependency' => array(
                        'element' => 'type_portfolio',
                        'value' => array(
                            'type-6',
                        )
                    ),
                ),

			)
		)
	);
}

add_action( 'vc_before_init', 'ivy_portfolio_fn_vc' );

if(class_exists('WPBakeryShortCode')) {
	class WPBakeryShortCode_ivy_portfolio_shortcode extends WPBakeryShortCode {
	}
}