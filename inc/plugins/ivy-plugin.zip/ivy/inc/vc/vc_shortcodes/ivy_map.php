<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_map_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Map", 'ivy'),
            "base" => "ivy_map_shortcode",
            'description' => esc_html__('Theme title', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'data-lat', 'ivy' ),
                    'param_name' => 'data_lat',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'data-lng', 'ivy' ),
                    'param_name' => 'data_lng',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'data-zoom', 'ivy' ),
                    'param_name' => 'data_zoom',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'data-string', 'ivy' ),
                    'param_name' => 'data_string',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'data-lat for marker', 'ivy' ),
                    'param_name' => 'data_lat_marker',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'data-lng for marker', 'ivy' ),
                    'param_name' => 'data_lng_marker',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',

                ),
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__( 'Marker Image', 'ivy' ),
                    'param_name' => 'data_marker',
                    'description' => esc_html__( '', 'ivy' ),
                    'value' => '',
                ),

            )
        )
    );

}

add_action('vc_before_init', 'ivy_map_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_map_shortcode extends WPBakeryShortCode
    {
    }
}