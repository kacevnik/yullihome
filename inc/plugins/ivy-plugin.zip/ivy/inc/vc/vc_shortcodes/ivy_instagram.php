<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_instagram_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Instagram", 'ivy'),
            "base" => "ivy_instagram_shortcode",
            'description' => esc_html__('Theme instagram', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Instagram Title', 'ivy' ),
                    'param_name' => 'title',
                    'description' => esc_html__( '', 'ivy' ),
                ),

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Instagram user ID:', 'ivy' ),
                    'param_name' => 'instagram_userid',
                    'description' => esc_html__( '', 'ivy' ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Instagram access token:', 'ivy' ),
                    'param_name' => 'instagram_access_token',
                    'description' => esc_html__( '', 'ivy' ),
                ),
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Instagram image limit:', 'ivy' ),
                    'param_name' => 'img_limit',
                    'description' => esc_html__( '', 'ivy' ),
                ),
            )
        )
    );

}

add_action('vc_before_init', 'ivy_instagram_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_instagram_shortcode extends WPBakeryShortCode
    {
    }
}