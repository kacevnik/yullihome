<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 *
 */
function ivy_our_clients_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Our Clients", 'ivy'),
            "base" => "ivy_our_clients_shortcode",
            'description' => esc_html__('Add clients', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            'as_parent'               => array('only' => 'ivy_our_clients_content_shortcode'),
            'content_element'         => true,
            "js_view" => 'VcColumnView',
            "params" => array(

                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Extra class name', 'ivy' ),
                    'param_name' => 'el_class',
                    'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'ivy' ),
                ),
                array(
                    'type' => 'css_editor',
                    'heading' => esc_html__('Css', 'ivy'),
                    'param_name' => 'css',
                    'group' => esc_html__('Design options', 'ivy'),
                ),
            )
        )
    );

}

add_action('vc_before_init', 'ivy_our_clients_fn_vc');

function ivy_our_clients_content_fn_vc() {

    vc_map(
        array(
            "icon" => 'tt-vc-block',
            'name'            => esc_html__('Client', 'ivy'),
            'base'            => 'ivy_our_clients_content_shortcode',
            'description'     => esc_html__( 'Create client', 'ivy' ),
            "category" => esc_html__('IVY', 'ivy'),
            'content_element' => true,
            'as_child'        => array('only' => 'ivy_our_clients_shortcode'),
            'params'          => array(
                array(
                    'type' => 'attach_image',
                    'heading' => esc_html__('Image', 'ivy'),
                    'param_name' => 'image',
                    'value' => '',
                    'description' => esc_html__('Select image from media library.', 'ivy'),
                ),
                array(
                    'type' => 'vc_link',
                    'heading' => esc_html__('URL Link', 'ivy'),
                    'param_name' => 'url',
                    'description' => esc_html__('', 'ivy'),
                ),


            ),
        )
    );
}
add_action( 'vc_before_init', 'ivy_our_clients_content_fn_vc' );

// A must for container functionality, replace Wbc_Item with your base name from mapping for parent container
if(class_exists('WPBakeryShortCodesContainer')){
    class WPBakeryShortCode_ivy_our_clients_shortcode extends WPBakeryShortCodesContainer {

    }
}

// Replace Wbc_Inner_Item with your base name from mapping for nested element
if(class_exists('WPBakeryShortCode')){
    class WPBakeryShortCode_ivy_our_clients_content_shortcode extends WPBakeryShortCode {

    }
}
