<?php
if (!defined('ABSPATH')) {
    die('-1');
}
/*
 *
 */
function ivy_spacer_fn_vc()
{
    vc_map(
        array(
            "icon" => 'tt-vc-block',
            "name" => esc_html__("Spacer", 'ivy'),
            "base" => "ivy_spacer_shortcode",
            'description' => esc_html__('Spacer', 'ivy'),
            "category" => esc_html__('IVY', 'ivy'),
            "params" => array(
                array(
                    'type' => 'textfield',
                    'heading' => esc_html__( 'Enter empty space (number)', 'ivy' ),
                    'param_name' => 'space',
                ),
            )
        )
    );
}

add_action('vc_before_init', 'ivy_spacer_fn_vc');

if (class_exists('WPBakeryShortCode')) {
    class WPBakeryShortCode_ivy_spacer_shortcode extends WPBakeryShortCode
    {
    }
}