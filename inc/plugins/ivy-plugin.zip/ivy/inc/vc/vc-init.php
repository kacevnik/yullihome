<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/*-----------------------------------------------------------------------------------*/
/* VC stuff for Templatation themes
/*-----------------------------------------------------------------------------------*/

$ivy_vc_sortcodes_dir = plugin_dir_path( __FILE__ );
// Set VC as theme.
if( function_exists('vc_set_as_theme') ){
    function ivy_vcAsTheme() {
        vc_set_as_theme(true);
    }
    add_action( 'vc_before_init', 'ivy_vcAsTheme' );
}

vc_set_shortcodes_templates_dir($ivy_vc_sortcodes_dir.'vc_templates/');
// Initialize VC modules.
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_video_box.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_title.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_list.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_image_link.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_models.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_team.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_slider.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_icon_box.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_button.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_last_posts_slider.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_subscribe.php');
//include( $sl_vc_sortcodes_dir . 'vc_shortcodes/sl_pslider.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_spacer.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_portfolio.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_title.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_about_block.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_our_clients.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_title_page.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider1.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider2.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider3.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider4.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider5.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider6.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider7.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider_about.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider_our_team.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_slider_our_team_full.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_header_image.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_services.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_social.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_we_offer.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_map.php');
include( $ivy_vc_sortcodes_dir . 'vc_shortcodes/ivy_instagram.php');

