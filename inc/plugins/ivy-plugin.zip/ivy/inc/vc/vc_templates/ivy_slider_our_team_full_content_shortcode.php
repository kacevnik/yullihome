<?php
/*
 *
 *
 */

$image = $image_border = $name = $desc = $position = $url_instagram = $url_facebook = $url_twitter = $url_google = $slider_type ='';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
$image = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';
$image_border = (is_numeric($image_border) && !empty($image_border)) ? wp_get_attachment_url($image_border) : '';
$name = !empty($name) ? $name : '';
$position = !empty($position) ? $position : '';
$desc = !empty($desc) ? $desc : '';

$url_instagram = ( '||' === $url_instagram ) ? '' : $url_instagram;
$url_instagram = vc_build_link( $url_instagram );

$url_facebook = ( '||' === $url_facebook) ? '' : $url_facebook;
$url_facebook= vc_build_link( $url_facebook);

$url_twitter = ( '||' === $url_twitter) ? '' : $url_twitter;
$url_twitter = vc_build_link( $url_twitter);

$url_google = ( '||' === $url_google) ? '' : $url_google;
$url_google= vc_build_link( $url_google);



if(!empty($image)) { ?>
<div class="swiper-slide">
    <div class="align full-screen-height">
        <div class="container">
            <div class="row vertical-aligned-columns">
                <div class="col-sm-6">
                    <div class="thumbnail-shortcode-5-wrapper">
                        <div class="thumbnail-shortcode-5">
                            <div class="content">
                                <div class="layer-1 border-image" style="border-image-source: url(<?php echo esc_url($image_border)?>);"></div>
                                <div class="layer-2"><img src="<?php echo esc_url($image)?>" alt="<?php echo esc_attr($name)?>"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="slider-about-text">
                        <div class="h1 slider-about-title"><?php echo esc_html($name)?></div>
                        <div class="slider-about-subtitle"><?php echo esc_html($position)?></div>
                        <div class="sa slider-about-description"><?php echo do_shortcode($desc)?></div>
                        <div class="follow">
                            <?php if (!empty($url_instagram['url'])) { ?>
                                <a class="entry" href="<?php echo esc_url($url_instagram['url']); ?>" target="<?php echo esc_attr($url_instagram['target']); ?>"><i class="fa fa-instagram"></i></a>
                            <?php } if (!empty($url_facebook['url'])) { ?>
                                <a class="entry" href="<?php echo esc_url($url_facebook['url']); ?>" target="<?php echo esc_attr($url_facebook['target']); ?>"><i class="fa fa-facebook"></i></a>
                            <?php } if (!empty($url_twitter['url'])) { ?>
                                <a class="entry" href="<?php echo esc_url($url_twitter['url']); ?>" target="<?php echo esc_attr($url_twitter['target']); ?>"><i class="fa fa-twitter"></i></a>
                            <?php } if (!empty($url_google['url'])) { ?>
                                <a class="entry" href="<?php echo esc_url($url_google['url']); ?>" target="<?php echo esc_attr($url_google['target']); ?>"><i class="fa fa-google-plus"></i></a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php } ?>