<?php
/*
 *
 *
 */

$image_top = $image_bottom = $image_border = $title = $title_hover = $desc = $text_right = $text_bottom = $url = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
$image_top = (is_numeric($image_top) && !empty($image_top)) ? wp_get_attachment_url($image_top) : '';
$image_bottom = (is_numeric($image_bottom) && !empty($image_bottom)) ? wp_get_attachment_url($image_bottom) : '';
$image_border = (is_numeric($image_border) && !empty($image_border)) ? wp_get_attachment_url($image_border) : '';

$title = !empty($title) ? $title : '';
$title_hover = !empty($title_hover) ? $title_hover : '';
$desc = !empty($desc) ? $desc : '';
$text_right = !empty($text_right) ? $text_right : '';
$text_bottom = !empty($text_bottom) ? $text_bottom : '';

$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );

?>


<div class="swiper-slide">
    <div class="leftside">
        <div class="sl right-align"><?php echo esc_html($text_right); ?></div>
        <div class="leftside-middle valign-middle">
            <div class="valign-middle-content">
                <div class="banner-frame border-image" style="border-image-source: url(<?php echo esc_url($image_border); ?>);" data-swiper-parallax-y="-100%">
                    <div class="content" data-swiper-parallax-y="-70%">
                        <div class="text">
                            <div class="text-container">
                                <div class="align">
                                    <div class="h3 title" style="color: <?php echo esc_attr($title_hover); ?>;"><span class="ht-1"><a href="<?php echo esc_url($url['url'])?>"><?php echo esc_html($title); ?></a></span></div>
                                    <div class="sa description"><?php echo esc_html($desc); ?></div>
                                    <a  class="button" href="<?php echo esc_url($url['url'])?>" target="<?php echo esc_attr($url['target'])?>"><?php echo esc_html($url['title'])?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sl left-align"><?php echo esc_html($text_bottom); ?></div>
    </div>
    <a class="right-top lightbox" href="<?php echo esc_url($image_top); ?>" data-swiper-parallax-y="100%">
        <div class="content" style="background-image: url(<?php echo esc_url($image_top); ?>);"></div>
        <div class="content" style="background-image: url(<?php echo esc_url($image_top); ?>);"></div>
    </a>
    <a class="right-bottom lightbox" href="<?php echo esc_url($image_bottom); ?>" data-swiper-parallax-y="100%">
        <div class="content" style="background-image: url(<?php echo esc_url($image_bottom); ?>);"></div>
        <div class="content" style="background-image: url(<?php echo esc_url($image_bottom); ?>);"></div>
    </a>
</div>