<?php
/*
 *
 */
$css= '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

?>


<div class="swiper-entry <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="swiper-button-prev visible-lg"></div>
    <div class="swiper-button-next visible-lg"></div>
    <div class="swiper-container" data-space="30">
        <div class="swiper-wrapper">
            <?php print do_shortcode($content); ?>
        </div>
        <div class="swiper-pagination relative-pagination hidden-lg"></div>
    </div>
</div>
