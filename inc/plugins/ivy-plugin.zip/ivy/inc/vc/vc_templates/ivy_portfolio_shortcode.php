<?php
$cats = $cat_one = $all_check = $type_click = $type_portfolio = $enab_all = $width_content = $default_letter = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$cats = str_replace(' ', '', $cats);
$catsArr = explode(",", $cats);



$count = 0;
foreach ($catsArr as $cat) {
    $cat = get_category($cat);
    if ($cat) $count += $cat->category_count;
}


if ($text_align == 'left'){
    $text_align = 'left';
} elseif ($text_align == 'right') {
    $text_align = 'right';
} else {
    $text_align = 'center';
}

if ($float == 'left'){
    $float= 'col-md-6 col-md-offset-1';
} elseif ($float == 'right') {
    $float = 'col-md-6 col-md-offset-5';
} else {
    $float = 'col-md-12';
}

$output = '';
function sorting_menu($count, $catsArr, $all_check) {
    $output = '<div class="sorting-menu">';
    $all_check = (!empty($all_check) && $all_check == 'hide') ? $all_check : '';
    $output .= '<div class="title">' . esc_html('All', THEME_DOMAIN) . '</div><div class="toggle">';
    $output .= '<a class="active '. esc_attr($all_check) .'" data-filter="*"><span class="text">'. esc_html('All', THEME_DOMAIN) . '</span><span class="number"> ' . $count . '</span></a>';
    if (!empty($catsArr) && !is_wp_error($catsArr)) {
        foreach ($catsArr as $cat) {
                $cat_name = get_the_category_by_ID($cat);
                if($cat_name) $output .= '<a data-filter=".'. esc_attr($cat_name) .'"><span class="text">' . esc_attr($cat_name) . '</span><span class="number">' . get_category($cat)->category_count . '</span></a>';
        }

    }
    $output .= '</div></div>';
    return $output;
}
/*************************************************************/
///*************************PORTFOLIO TYPE 1******************/
/*************************************************************/
if ($type_portfolio == 'type-1') { ?>

    <div class="<?php echo esc_attr($float);?> text-<?php echo esc_attr($text_align);?>" style="float: none;">
        <?php echo sorting_menu($count, $catsArr, $all_check); ?>
        <div class="empty-space col-xs-b25 col-sm-b50"></div>
    </div>
    <div class="sorting-container portfolio-3">
        <div class="grid-sizer w50"></div>

        <?php
        $args = array('posts_per_page' => -1, 'post_type' => 'portfolio',
            'tax_query' => array(
                array(
                    'taxonomy' => 'portfolio_cats',
                    'field' => 'term_id',
                    'terms' => $catsArr,
                ),
            ),
        );
        $query = new WP_Query($args);

        if( $query->have_posts() ) :
            while ($query->have_posts()) : $query->the_post();

        $curent_term_array = wp_get_post_terms(get_the_ID(), 'portfolio_cats');
        $curent_term_string = '';
        foreach ($curent_term_array as $curent_term_item) {
            $curent_term_string .= ' ' . $curent_term_item->name;
        }

        // aq resizer
        $thumb = get_post_thumbnail_id();
        $img_url = wp_get_attachment_url( $thumb,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
        $image = aq_resize( $img_url, '923', '808', true, true, true ); //resize & crop the image
                    
?>
        <div class="sorting-item w50 <?php echo esc_attr($curent_term_string); ?>">
            <div class="portfolio-preview-3">
                <?php if ($type_click == 'type-one') { ?>
                    <a class="lightbox" href="<?php echo esc_url($image); ?>">
                        <img class="preview" src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" />
                        <span class="portfolio-hover-3">
                        <span class="bg-layer"></span>
                        <span class="frame-layer"></span>
                        <span class="align">
                            <span class="title h3 light"><?php the_title(); ?></span>
                        </span>
                    </span>
                    </a>
                <?php } elseif ($type_click == 'type-two') { ?>
                    <a href="<?php the_permalink(); ?>">
                        <img class="preview" src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" />
                        <span class="portfolio-hover-3">
                        <span class="bg-layer"></span>
                        <span class="frame-layer"></span>
                        <span class="align">
                            <span class="title h3 light"><?php the_title(); ?></span>
                        </span>
                    </span>
                    </a>
                <?php } ?>
            </div>
        </div>
        <?php endwhile; wp_reset_postdata(); endif; ?>
    </div>


<?php }
/*************************************************************/
///*************************PORTFOLIO TYPE 2******************/
/*************************************************************/
elseif ($type_portfolio == 'type-2') { ?>

        <div class="<?php echo esc_attr($float);?> text-<?php echo esc_attr($text_align);?>" style="float: none;">
            <?php echo sorting_menu($count, $catsArr, $all_check); ?>
            <div class="empty-space col-xs-b25 col-sm-b50"></div>
        </div>
        <div class="sorting-container portfolio-4 ml93">
            <div class="grid-sizer w50"></div>
        <?php
        $args = array('posts_per_page' => -1, 'post_type' => 'portfolio',
            'tax_query' => array(
                array(
                    'taxonomy' => 'portfolio_cats',
                    'field' => 'term_id',
                    'terms' => $catsArr,
                ),
            ),
        );
        $query = new WP_Query($args);
        if( $query->have_posts() ) :
        while ($query->have_posts()) : $query->the_post();

            $curent_term_array = wp_get_post_terms(get_the_ID(), 'portfolio_cats');
            $curent_term_string = '';
            $display_cats = array();
            foreach ($curent_term_array as $curent_term_item) {
                $curent_term_string .= ' ' . $curent_term_item->name;
                $display_cats[] =  $curent_term_item->name;
            }
            $display_cats = implode( ' / ', $display_cats );


            // aq resizer
            $thumb = get_post_thumbnail_id();
            $img_url = wp_get_attachment_url( $thumb,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
            $image = aq_resize( $img_url, '814', '607', true, true, true ); //resize & crop the image
 
            ?>

            <div class="sorting-item w50 <?php echo esc_attr($curent_term_string); ?>">
                <div class="portfolio-preview-4">
                    <a class="mouseover-1 lightbox" href="<?php the_post_thumbnail_url(); ?>">
                        <img src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" />
                        <img src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" />
                    </a>
                    <div class="h6 title"><span class="ht-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span></div>
                    <div class="sl"><?php echo esc_html($display_cats); ?></div>
                </div>
            </div>
        <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>

<?php }
/*************************************************************/
///***********************PORTFOLIO TYPE 3********************/
/*************************************************************/
elseif ($type_portfolio == 'type-3') {
    ($width_content == 'container-fluid') ? $width_content = 'container-fluid' : $width_content = 'container';
    ?>
    <div class="<?php echo esc_attr($width_content); ?> ">
        <div class="<?php echo esc_attr($float);?> text-<?php echo esc_attr($text_align);?>" style="float: none; padding: 0;">
            <?php echo sorting_menu($count, $catsArr, $all_check); ?>
            <div class="empty-space col-xs-b25 col-sm-b50"></div>
        </div>
        <div class="sorting-container portfolio-1">
            <div class="grid-sizer w25"></div>

            <?php
            $args = array('posts_per_page' => -1, 'post_type' => 'portfolio',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'portfolio_cats',
                        'field' => 'term_id',
                        'terms' => $catsArr,
                    ),
                ),
            );
            $query = new WP_Query($args);
            if( $query->have_posts() ) :
                $counter = 1;
                while ($query->have_posts()) : $query->the_post();

                    $curent_term_array = wp_get_post_terms(get_the_ID(), 'portfolio_cats');
                    $curent_term_string = '';
                    $display_cats = array();
                    foreach ($curent_term_array as $curent_term_item) {
                        $curent_term_string .= ' ' . $curent_term_item->name;
                        $display_cats[] =  $curent_term_item->name;
                    }
                    $display_cats = implode( ' / ', $display_cats );

                    $visible_type='';
                    $size='';
                    switch ($counter) {
                        case 1:
                            $visible_type = 'w50';
                            if ($width_content == 'container-fluid') {
                                $height = '923';
                                $width = '923';
                            } else {
                                $height = '570';
                                $width = '570';
                            }
                            break;
                        case 2:
                            $visible_type = 'w25';
                            if ($width_content == 'container-fluid') {
                                $height = '461';
                                $width = '461';
                            } else {
                                $height = '285';
                                $width = '285';
                            }
                            break;
                        case 3:
                            $visible_type = 'w25';
                            if ($width_content == 'container-fluid') {
                                $height = '461';
                                $width = '461';
                            } else {
                                $height = '285';
                                $width = '285';
                            }
                            break;
                        case 4:
                            $visible_type = 'w50';
                            if ($width_content == 'container-fluid') {
                                $height = '462';
                                $width = '923';
                            } else {
                                $height = '285';
                                $width = '570';
                            }
                            break;
                        case 5:
                            $visible_type = 'w25';
                            if ($width_content == 'container-fluid') {
                                $height = '461';
                                $width = '461';
                            } else {
                                $height = '285';
                                $width = '285';
                            }
                            break;
                        case 6:
                            $visible_type = 'w25';
                            if ($width_content == 'container-fluid') {
                                $height = '461';
                                $width = '461';
                            } else {
                                $height = '285';
                                $width = '285';
                            }
                            break;
                        case 7:
                            $visible_type = 'w50';
                            if ($width_content == 'container-fluid') {
                                $height = '923';
                                $width = '923';
                            } else {
                                $height = '570';
                                $width = '570';
                            }
                            break;
                        case 8:
                            $visible_type = 'w25';
                            if ($width_content == 'container-fluid') {
                                $height = '461';
                                $width = '461';
                            } else {
                                $height = '285';
                                $width = '285';
                            }
                            break;
                        case 9:
                            $visible_type = 'w25';
                            if ($width_content == 'container-fluid') {
                                $height = '461';
                                $width = '461';
                            } else {
                                $height = '285';
                                $width = '285';
                            }
                            break;
                        case 10:
                            $visible_type = 'w50';
                            $height = '233';
                            $width = '553';
                            break;
                        case 11:
                            $visible_type = 'w25';
                            $height = '233';
                            $width = '553';
                            break;
                        case 12:
                            $visible_type = 'w25';
                            $height = '233';
                            $width = '553';
                            break;
                        case 13:
                            $visible_type = 'w25';
                            $height = '233';
                            $width = '553';
                            break;
                        case 14:
                            $visible_type = 'w25';
                            $height = '233';
                            $width = '553';
                            break;
                        case 15:
                            $visible_type = 'w50';
                            $height = '233';
                            $width = '553';
                            break;
                    }

                    // aq resizer
                    $thumb = get_post_thumbnail_id();
                    $img_url = wp_get_attachment_url( $thumb,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
                    $image = aq_resize( $img_url, $width, $height, true, true, true ); //resize & crop the image
                    ?>
            <div class="sorting-item <?php echo esc_attr($visible_type) .' '. $curent_term_string ?>">
                <div class="portfolio-preview-1">
                    <?php if ($type_click == 'type-one') { ?>
                    <a href="<?php echo esc_url($image); ?>" class="lightbox">
                        <img class="preview" src="<?php echo esc_url($image); ?>" alt="<?php the_title() ?>" />
                        <span class="valign-middle portfolio-hover-1">
                        <span class="valign-middle-content">
                            <span class="title h4"><?php the_title() ?></span>
                            <span class="description sa dark small"><?php echo esc_html($display_cats); ?></span>
                        </span>
                    </span>
                    </a>
                    <?php } elseif ($type_click == 'type-two') { ?>
                        <a href="<?php the_permalink(); ?>">
                            <img class="preview" src="<?php echo esc_url($image); ?>" alt="<?php the_title() ?>" />
                            <span class="valign-middle portfolio-hover-1">
                            <span class="valign-middle-content">
                            <span class="title h4"><?php the_title() ?></span>
                            <span class="description sa dark small"><?php echo esc_html($display_cats); ?></span>
                        </span>
                    </span>
                        </a>
                    <?php } ?>
                </div>

            </div>
            <?php
                    if ($width_content == 'container'){
                        ($counter > 15) ? $counter = 0 : $counter++;
                    } elseif ($width_content == 'container-fluid') {
                        ($counter > 9) ? $counter = 0 : $counter++;
                    }
             endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </div>


<?php }
/*************************************************************/
///***********************PORTFOLIO TYPE 4********************/
/*************************************************************/
elseif ($type_portfolio == 'type-4') { ?>
    <div class="container">
        <div class="row">
            <div class="<?php echo esc_attr($float);?> text-<?php echo esc_attr($text_align);?>" style="float: none;">
                <?php echo sorting_menu($count, $catsArr, $all_check); ?>
                <div class="empty-space col-xs-b25 col-sm-b50"></div>
            </div>
        </div>
        <div class="sorting-container portfolio-1">
            <div class="grid-sizer w33"></div>
            <?php
            $args = array('posts_per_page' => -1, 'post_type' => 'portfolio',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'portfolio_cats',
                        'field' => 'term_id',
                        'terms' => $catsArr,
                    ),
                ),
            );
            $query = new WP_Query($args);
            if( $query->have_posts() ) :
                while ($query->have_posts()) : $query->the_post();

            $curent_term_array = wp_get_post_terms(get_the_ID(), 'portfolio_cats');
            $curent_term_string = '';
            $display_cats = array();
            foreach ($curent_term_array as $curent_term_item) {
                $curent_term_string .= ' ' . $curent_term_item->name;
                $display_cats[] =  $curent_term_item->name;
            }
            $display_cats = implode( ' / ', $display_cats );
            // $type_click = ($type_click == 'type-one') ? $type_click = get_the_post_thumbnail_url() : $type_click = get_permalink();
            // aq resizer
            $thumb = get_post_thumbnail_id();
            $img_url = wp_get_attachment_url( $thumb,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
            $image = aq_resize( $img_url, '370', '370', true, true, true ); //resize & crop the image

            ?>
            <div class="sorting-item w33 <?php echo esc_attr($curent_term_string); ?>">
                <div class="portfolio-preview-1">
                    <?php if ($type_click == 'type-one') { ?>
                        <a href="<?php the_permalink() ?>" class="lightbox">
                            <img class="preview" src="<?php echo esc_url($image); ?>" alt="<?php the_title() ?>" />
                            <span class="valign-middle portfolio-hover-1">
                        <span class="valign-middle-content">
                            <span class="title h4"><?php the_title() ?></span>
                            <span class="description sa dark small"><?php echo esc_html($display_cats); ?></span>
                        </span>
                    </span>
                        </a>
                    <?php } elseif ($type_click == 'type-two') { ?>
                        <a href="<?php the_permalink(); ?>">
                            <img class="preview" src="<?php echo esc_url($image); ?>" alt="<?php the_title() ?>" />
                            <span class="valign-middle portfolio-hover-1">
                        <span class="valign-middle-content">
                            <span class="title h4"><?php the_title() ?></span>
                            <span class="description sa dark small"><?php echo esc_html($display_cats); ?></span>
                        </span>
                    </span>
                        </a>
                    <?php } ?>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </div>

<?php }
/*************************************************************/
///***********************PORTFOLIO TYPE 5********************/
/*************************************************************/
elseif ($type_portfolio == 'type-5') { ?>
        <div class="row portfolio-5">
            <?php
            if ($enab_all == 'all'){
                $args = array('posts_per_page' => -1, 'post_type' => 'portfolio');
            } else {
                $args = array('posts_per_page' => -1, 'post_type' => 'portfolio',
                    'tax_query' => array(
                        array(
                            'taxonomy' => 'portfolio_cats',
                            'field' => 'term_id',
                            'terms' => array($cat_one),
                        ),
                    ),
                );
            }
            $query = new WP_Query($args);

            if( $query->have_posts() ) :
                while ($query->have_posts()) : $query->the_post(); 

            // aq resizer
            $thumb = get_post_thumbnail_id();
            $img_url = wp_get_attachment_url( $thumb,'full' ); //get full URL to image (use "large" or "medium" if the images too big)
            $image = aq_resize( $img_url, '280', '280', true, true, true ); //resize & crop the image

            ?>
            <div class="col-sm-4">
                <div class="portfolio-preview-5">
                    <a class="preview mouseover-1 lightbox" href="<?php the_post_thumbnail_url(); ?>">
                        <img src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" />
                        <img src="<?php echo esc_url($image); ?>" alt="<?php the_title(); ?>" />
                    </a>
                    <div class="h6 title"><span class="ht-2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span></div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>

<?php }
/*************************************************************/
///***********************PORTFOLIO TYPE 6********************/
/*************************************************************/
elseif ($type_portfolio == 'type-6') { ?>

    <div class="container-fluid">
        <div class="row">
            <div class="<?php echo esc_attr($float);?> text-<?php echo esc_attr($text_align);?>" style="float: none;">
                <?php echo sorting_menu($count, $catsArr, $all_check);?>
                <div class="empty-space col-xs-b25 col-sm-b50"></div>
            </div>
        </div>


        <div class="sorting-container portfolio-2">
            <div class="grid-sizer w25"></div>
            <?php
            $portfolio_opt = '';
            $args = array('posts_per_page' => -1, 'post_type' => 'portfolio',
                'tax_query' => array(
                    array(
                        'taxonomy' => 'portfolio_cats',
                        'field' => 'term_id',
                        'terms' => $catsArr,
                    ),
                ),
            );
            $query = new WP_Query($args);
            if( $query->have_posts() ) :
                while ($query->have_posts()) : $query->the_post();

                $portfolio_opt = get_post_meta(get_the_ID(), '_ivy_portfolio_meta_opt', true);
                $portfolio_letter = !empty($portfolio_opt["portfolio_letter"]) ? $portfolio_opt["portfolio_letter"] : $default_letter;
                $portfolio_label = !empty($portfolio_opt["portfolio_label"]) ? $portfolio_opt["portfolio_label"] : '';

                $curent_term_array = wp_get_post_terms(get_the_ID(), 'portfolio_cats');
                $curent_term_string = '';
                foreach ($curent_term_array as $curent_term_item) {
                    $curent_term_string = ' ' . $curent_term_item->name;
                    $display_cats =  $curent_term_item->name;
                }
            ?>
            <div class="sorting-item w25 <?php echo esc_attr($curent_term_string);?>">
                <div class="portfolio-preview-2">
                    <a href="<?php the_permalink() ?>">
                        <span class="text-mask" style="background-image: url(<?php the_post_thumbnail_url()?>);"><span class="text"><span class="text-align" data-letter="<?php echo esc_html($portfolio_letter)?>"></span></span></span>
                        <span class="label-1"><?php echo esc_html($curent_term_string); ?></span>
                        <span class="label-2"><?php echo esc_html($portfolio_label); ?></span>
                        <span class="portfolio-hover-2" style="background-image: url(<?php the_post_thumbnail_url()?>);"></span>
                    </a>
                    <div class="top-icon"></div>
                </div>
            </div>
            <?php endwhile; wp_reset_postdata(); endif; ?>
        </div>
    </div>


<?php } ?>
