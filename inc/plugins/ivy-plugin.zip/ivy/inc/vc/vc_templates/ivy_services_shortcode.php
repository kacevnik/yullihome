<?php
/*
 *
 */
$css = $position = $image = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

($position == 'right') ? $position = 'style-1' : '';

$image = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';
$top_text = !empty($top_text) ? $top_text : '';
$title = !empty($title) ? $title : '';
$desc = !empty($desc) ? $desc : '';
$letter = !empty($letter) ? $letter : '';


?>


<div class="services-shortcode-1 <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?> <?php echo esc_attr($position); ?>">
    <div class="preview-wrapper">
        <div class="icon"></div>
        <div class="icon"></div>
        <div class="icon"></div>
        <div class="icon"></div>
        <div class="preview">
            <span class="text-mask" style="background-image: url(<?php echo esc_url($image); ?>);"><span class="text"><span class="text-align" data-letter="<?php echo esc_attr($letter); ?>"></span></span></span>
        </div>
    </div>
    <div class="content">
        <div class="align">
            <div class="sl"><?php echo esc_html($top_text); ?></div>
            <div class="sa">
                <h4 class="h4 title"><?php echo esc_html($title); ?></h4>
                <?php echo do_shortcode($desc); ?>
            </div>
        </div>
    </div>
</div>