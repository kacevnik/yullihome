<?php
/*
 *
 */
$css = $url_instagram = $url_facebook = $url_twitter = $url_google = $slider_type = $position = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);


$url_instagram = ( '||' === $url_instagram ) ? '' : $url_instagram;
$url_instagram = vc_build_link( $url_instagram );

$url_facebook = ( '||' === $url_facebook) ? '' : $url_facebook;
$url_facebook= vc_build_link( $url_facebook);

$url_twitter = ( '||' === $url_twitter) ? '' : $url_twitter;
$url_twitter = vc_build_link( $url_twitter);

$url_google = ( '||' === $url_google) ? '' : $url_google;
$url_google= vc_build_link( $url_google);


?>

<div class="text-<?php echo esc_attr($position); ?> <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="follow">
        <?php if (!empty($url_instagram['url'])) { ?>
            <a class="entry" href="<?php echo esc_url($url_instagram['url']); ?>" target="<?php echo esc_attr($url_instagram['target']); ?>"><i class="fa fa-instagram"></i></a>
        <?php } if (!empty($url_facebook['url'])) { ?>
            <a class="entry" href="<?php echo esc_url($url_facebook['url']); ?>" target="<?php echo esc_attr($url_facebook['target']); ?>"><i class="fa fa-facebook"></i></a>
        <?php } if (!empty($url_twitter['url'])) { ?>
            <a class="entry" href="<?php echo esc_url($url_twitter['url']); ?>" target="<?php echo esc_attr($url_twitter['target']); ?>"><i class="fa fa-twitter"></i></a>
        <?php } if (!empty($url_google['url'])) { ?>
            <a class="entry" href="<?php echo esc_url($url_google['url']); ?>" target="<?php echo esc_attr($url_google['target']); ?>"><i class="fa fa-google-plus"></i></a>
        <?php } ?>
    </div>
</div>