<?php
/*
 *
 *
 */

$image1 = $image2 = $image3 = $image4 = $title_hover = $text_left = $text_bottom = $url = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$image1 = (is_numeric($image1) && !empty($image1)) ? wp_get_attachment_url($image1) : '';
$image2 = (is_numeric($image2) && !empty($image2)) ? wp_get_attachment_url($image2) : '';
$image3 = (is_numeric($image3) && !empty($image3)) ? wp_get_attachment_url($image3) : '';
$image4 = (is_numeric($image4) && !empty($image4)) ? wp_get_attachment_url($image4) : '';


$title_hover = !empty($title_hover) ? $title_hover : '';

$text_left = !empty($text_left) ? $text_left : '';
$text_bottom = !empty($text_bottom) ? $text_bottom : '';

$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );



?>

<div class="swiper-slide">
    <div class="container-fluid wide">
        <div class="image-preview image-1" data-swiper-parallax-y="-55%" style="background-image: url(<?php echo esc_url($image1); ?>);"><div class="content"></div></div>
        <div class="image-preview image-2" data-swiper-parallax-y="-35%" style="background-image: url(<?php echo esc_url($image2); ?>);"><div class="content"></div></div>
        <div class="image-preview image-3" data-swiper-parallax-y="-70%" style="background-image: url(<?php echo esc_url($image3); ?>);"><div class="content"></div></div>
        <div class="image-preview image-4" data-swiper-parallax-y="-40%" style="background-image: url(<?php echo esc_url($image4); ?>);"><div class="content"></div></div>
        <div class="sl-entry sl-1">
            <div class="sl"><?php echo esc_html($text_bottom); ?></div>
        </div>
        <div class="sl-entry sl-2">
            <div class="sl"><?php echo esc_html($text_left); ?></div>
        </div>
        <div class="title-wrapper valign-middle">
            <div class="content">
                <div class="h1 title text-center" style="color: <?php echo esc_attr($title_hover); ?>;"><span class="ht-1"><a href="<?php echo esc_url($url['url'])?>"><?php echo esc_html($url['title'])?></a></span></div>
            </div>
        </div>
    </div>
</div>