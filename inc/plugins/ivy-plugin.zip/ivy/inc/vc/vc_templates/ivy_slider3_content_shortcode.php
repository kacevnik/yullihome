<?php
/*
 *
 *
 */

$image_left = $image_right = $title_hover = $text_top = $text_bottom = $url = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$image_left = (is_numeric($image_left) && !empty($image_left)) ? wp_get_attachment_url($image_left) : '';
$image_right = (is_numeric($image_right) && !empty($image_right)) ? wp_get_attachment_url($image_right) : '';


$title_hover = !empty($title_hover) ? $title_hover : '';

$text_top = !empty($text_top) ? $text_top : '';
$text_bottom = !empty($text_bottom) ? $text_bottom : '';

$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );

?>

<div class="slice-slider-slide">
    <div class="slice-slider-slide-left">
        <div class="slice-align-animation scale">
            <div class="slice-slider-align-2">
                <div class="sl top"><?php echo esc_html($text_top); ?></div>
                <div class="rotate">
                    <div class="h2 title" style="color: <?php echo esc_attr($title_hover); ?>;"><span class="ht-1"><a href="<?php echo esc_url($url['url'])?>"><?php echo esc_html($url['title'])?></a></span></div>
                </div>
                <div class="preview-wrapper">
                    <a class="preview" href="<?php echo esc_url($url['url'])?>" style="background-image: url(<?php echo esc_url($image_left)?>);">
                        <span class="hover-icon">
                            <span class="content"></span>
                        </span>
                    </a>
                </div>
                <div class="sl bottom"><?php echo esc_html($text_bottom); ?></div>
            </div>
        </div>
    </div>
    <div class="slice-slider-slide-right">
        <div class="slice-align-animation parallax">
            <div class="slice-slider-align-1" style="background-image: url(<?php echo esc_url($image_right)?>);"></div>
        </div>
    </div>
</div>