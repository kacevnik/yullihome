<?php
/*
 *
 */

$title_text = $subtitle_text = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);

$instagram_userid = strip_tags($atts['instagram_userid']);
$instagram_access_token = strip_tags($atts['instagram_access_token']);
$inst_id = uniqid();
$img_limit = strip_tags($atts['img_limit']);
$title = strip_tags($atts['title']);

?>


<div class="row">
    <div class="col-md-12 text-center">
        <article class="sa">
            <h3><?php print esc_html($title); ?></h3>
        </article>
        <div class="empty-space col-xs-b25 col-sm-b50"></div>
        <div class="row m30" id="<?php echo $inst_id;?>">
            <!--item photo-->
        </div>
    </div>
</div>


<script type="text/javascript">
    jQuery(document).ready(function($) {
        //Instagram
        try{Typekit.load();}catch(e){}
        var feed = new Instafeed({
            get: 'user',
            userId: '<?php echo $instagram_userid; ?>',
            'limit': '<?php echo $img_limit; ?>',
            accessToken: '<?php echo $instagram_access_token; ?>',
            template: '<div class="col-xs-6 col-sm-3 col-md-2" ><a class="thumbnail-shortcode-2 mouseover-1" href="{{link}}" target="_blank"><img src="{{image}}"/><img src="{{image}}"/></a></div>',
            target: '<?php echo $inst_id;?>',
            resolution: 'standard_resolution',
            after: function() {
            }
        });

        feed.run();


    });

</script>



