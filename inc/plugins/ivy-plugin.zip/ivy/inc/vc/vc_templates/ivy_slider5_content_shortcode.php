<?php
/*
 *
 *
 */

$image = $text_left = $text_right = $text_bottom = $url = $title_hover = $letter = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$image = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';

$text_left = !empty($text_left) ? $text_left : '';
$text_right = !empty($text_right) ? $text_right : '';

$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );

?>

<div class="swiper-slide">
    <div class="align full-screen-height">
        <div class="slider-5-entry">
            <div class="icon"></div>
            <div class="icon"></div>
            <div class="icon"></div>
            <div class="icon"></div>
            <div class="sl-wrapper">
                <div class="sl"><?php echo esc_html($text_left); ?></div>
            </div>
            <div class="preview">
                <span class="text-mask" style="background-image: url(<?php echo esc_url($image)?>);"><span class="text"><span class="text-align" data-letter="<?php echo esc_attr($letter); ?>"></span></span></span>
            </div>
            <div class="title-wrapper">
                <div class="sl"><?php echo esc_html($text_right); ?></div>
                <div class="h3 title" style="color: <?php echo esc_attr($title_hover); ?>;"><span class="ht-1"><a href="<?php echo esc_url($url['url'])?>"><?php echo esc_html($url['title'])?></a></span></div>
            </div>
        </div>
    </div>
</div>