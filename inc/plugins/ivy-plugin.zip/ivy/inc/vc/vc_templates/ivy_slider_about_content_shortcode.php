<?php
/*
 *
 *
 */

$image = $image_border = $name = $position = $url = $position_photo = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
$image = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';
$image_border = (is_numeric($image_border) && !empty($image_border)) ? wp_get_attachment_url($image_border) : '';
$title = !empty($title) ? $title : '';
$desc = !empty($desc) ? $desc : '';

$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );

if(!empty($image)) {

    if($position_photo == 'right'){
        $position_push = 'col-sm-push-5';
        $position_pull = 'col-sm-pull-7';
    } else{
        $position_push = '';
        $position_pull = '';
    }

    ?>
    <div class="swiper-slide">
        <div class="row vertical-aligned-columns">
            <div class="col-sm-7 <?php echo esc_attr($position_push); ?> col-xs-b30 col-sm-b0">
                <div class="thumbnail-shortcode-6">
                    <div class="content">
                        <div class="layer-1 border border-image" style="border-image-source: url(<?php echo esc_url($image_border)?>);"></div>
                        <div class="layer-2 background" style="background-image: url(<?php echo esc_url($image)?>);"></div>
                    </div>
                </div>
            </div>
            <div class="col-sm-5 <?php echo esc_attr($position_pull); ?>">
                <div class="sa">
                    <h3><?php echo esc_html($title); ?></h3>
                    <p><?php echo do_shortcode($desc); ?></p>
                    <a class="button style-2" href="<?php echo esc_url($url['url']);?>"><?php echo esc_html($url['title']); ?></a>
                </div>
            </div>
        </div>
    </div>
<?php } ?>