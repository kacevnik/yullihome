<?php
/*
 *
 */
$image = $image_back = $image_border = $title_text = $desc = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$image = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';
$image_back = (is_numeric($image_back) && !empty($image_back)) ? wp_get_attachment_url($image_back) : '';
$image_border = (is_numeric($image_border) && !empty($image_border)) ? wp_get_attachment_url($image_border) : '';
$title_text = !empty($title_text) ? $title_text : '';
$desc = !empty($desc) ? $desc : '';
?>
<div class="row vertical-aligned-columns">
    <div class="col-sm-7 col-sm-push-5 col-xs-b30 col-sm-b0">
        <div class="thumbnail-shortcode-4">
            <div class="content">
                <div class="layer-1 background" style="background-image: url(<?php echo esc_url($image_back); ?>);"></div>
                <div class="layer-2 border border-image" style="border-image-source: url(<?php echo esc_url($image_border); ?>);"></div>
                <div class="layer-3 background" style="background-image: url(<?php echo esc_url($image); ?>);"></div>
            </div>
        </div>
    </div>
    <div class="col-sm-5 col-sm-pull-7">
        <div class="sa">
            <h3><?php echo esc_html($title_text);?></h3>
            <?php echo do_shortcode($desc);?>
        </div>
    </div>
</div>