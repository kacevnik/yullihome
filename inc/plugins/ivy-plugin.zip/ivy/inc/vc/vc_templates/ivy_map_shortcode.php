<?php
/*
 *
 */

//register scripts
wp_enqueue_script('goog_maps');
wp_enqueue_script('map');

$data_lat = $data_lng = $data_zoom = $data_string = $data_marker = $data_lng_marker = $data_lat_marker = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$data_lat = !empty($data_lat) ? $data_lat : '';
$data_lng = !empty($data_lng) ? $data_lng : '';
$data_zoom = !empty($data_zoom) ? $data_zoom : '';
$data_string = !empty($data_string) ? $data_string : '';

$data_marker =  (is_numeric($data_marker) && !empty($data_marker)) ? wp_get_attachment_url($data_marker) : '';

?>

<div class="map-inst" id="map-canvas" data-lat="<?php echo esc_attr($data_lat); ?>" data-lng="<?php echo esc_attr($data_lng); ?>" data-zoom="<?php echo esc_attr($data_zoom); ?>"></div>
<div class="addresses-block hidden" data-rel="map-canvas">
    <a class="marker" data-marker="<?php echo esc_url($data_marker); ?>" data-lat="<?php echo esc_attr($data_lat_marker); ?>" data-lng="<?php echo esc_attr($data_lng_marker); ?>" data-string="<?php echo esc_attr($data_string); ?>"></a>
</div>