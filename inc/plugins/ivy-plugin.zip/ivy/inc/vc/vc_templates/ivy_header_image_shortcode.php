<?php
/*
 *
 */

$width_text = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
$image_header = (is_numeric($image_header) && !empty($image_header)) ? wp_get_attachment_url($image_header) : '';
$image_header_border = (is_numeric($image_header_border) && !empty($image_header_border)) ? wp_get_attachment_url($image_header_border) : '';

if ($width_text == 'full'){
    $width_text = "col-md-12";
} elseif($width_text == 'default') {
    $width_text = "col-md-8 col-md-offset-2";
}

?>
<div class="fixed-background" style="background-image: url(<?php echo esc_url($image_header)?>);">
    <div class="banner-shortcode">
        <div class="banner-frame border-image" style="border-image-source: url(<?php echo esc_url($image_header_border)?>);"></div>
        <div class="container">
            <div class="row">
                <div class="<?php echo esc_attr($width_text); ?>">
                    <div class="align">
                        <h1 class="h1 light"><?php echo esc_html($title_text)?></h1>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>