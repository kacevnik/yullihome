<?php
/*
 *
 *
 */

$image_top = $image_bottom = $text_top = $text_bottom = $text_bottom = $url_top = $url_bottom = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$image_top = (is_numeric($image_top) && !empty($image_top)) ? wp_get_attachment_url($image_top) : '';
$image_bottom = (is_numeric($image_bottom) && !empty($image_bottom)) ? wp_get_attachment_url($image_bottom) : '';

$text_top = !empty($text_top) ? $text_top : '';
$text_bottom = !empty($text_bottom) ? $text_bottom : '';

$url_top = ( '||' === $url_top ) ? '' : $url_top;
$url_top = vc_build_link( $url_top );

$url_bottom = ( '||' === $url_bottom ) ? '' : $url_bottom;
$url_bottom = vc_build_link( $url_bottom );

?>

<div class="swiper-slide">
    <div class="align full-screen-height">
        <div class="slider-4-entry">
            <a href="<?php echo esc_url($url_top['url'])?>" class="image" style="background-image: url(<?php echo esc_url($image_top); ?>);">
                <span class="content"></span>
            </a>
            <div class="h4 title"><span class="ht-2"><a href="<?php echo esc_url($url_top['url'])?>"><?php echo esc_html($url_top['title'])?></a></span></div>
            <span class="sl-wrapper"><span class="sl"><?php echo esc_html($text_top); ?></span></span>
        </div>
        <div class="slider-4-entry style-1">
            <a href="<?php echo esc_url($url_bottom['url'])?>" class="image" style="background-image: url(<?php echo esc_url($image_bottom); ?>);">
                <span class="content"></span>
            </a>
            <div class="h4 title"><span class="ht-2"><a href="<?php echo esc_url($url_bottom['url'])?>"><?php echo esc_html($url_bottom['title'])?></a></span></div>
            <span class="sl-wrapper"><span class="sl"><?php echo esc_html($text_bottom); ?></span></span>
        </div>
    </div>
</div>