<?php
/*
 *
 */
$title_text = $subtitle_text = $text_align = $float = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

if ($text_align == 'left'){
    $text_align = 'left';
} elseif ($text_align == 'right') {
    $text_align = 'right';
} else {
    $text_align = 'center';
}

if ($float == 'left'){
    $float= 'col-md-6 col-md-offset-1';
} elseif ($float == 'right') {
    $float = 'col-md-6 col-md-offset-5';
} else {
    $float = 'col-md-12';
}

?>

<div class="<?php echo esc_attr($float);?> text-<?php echo esc_attr($text_align);?> <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>"  style="float: none;">
    <article class="sa">
        <h3><?php echo esc_html($title_text);?></h3>
        <p><?php echo esc_html($subtitle_text);?></p>
    </article>
</div>