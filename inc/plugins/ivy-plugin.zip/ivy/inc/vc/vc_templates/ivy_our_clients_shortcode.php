<?php
/*
 *
 */
$title_text = $subtitle_text = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
?>
<div class="row">
    <?php echo do_shortcode($content); ?>
</div>