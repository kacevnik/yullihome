<?php
/*
 *
 */
$css = '';
$type = 'test';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);



?>


<div class="swiper-entry slider-1 <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="swiper-container full-screen-height" data-direction="vertical" data-parallax="1" data-mousewheel="1" data-speed="1000">
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-wrapper">
            <?php print do_shortcode($content); ?>
        </div>
        <div class="swiper-pagination visible-xs"></div>
        <div class="swiper-pager hidden-xs">
            <div class="swiper-pager-current">01</div>
            <div class="swiper-pager-total"></div>
        </div>
    </div>
</div>
