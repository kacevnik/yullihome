<?php
/*
 *
 */
$title_text = $subtitle_text = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
?>
<div class="text-center">
    <h6 class="h6 col-xs-b10"><?php echo esc_html($title_text);?></h6>
    <div class="sa middle"><?php echo esc_html($subtitle_text);?></div>
</div>