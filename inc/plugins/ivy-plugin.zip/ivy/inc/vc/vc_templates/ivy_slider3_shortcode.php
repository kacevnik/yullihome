<?php
/*
 *
 */

wp_enqueue_script('mousewheel');
wp_enqueue_script('sliceslider');

$css = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

?>

<div class="full-screen-height slider-3 <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="slice-slider-container">
        <div class="slice-slider-right-column">
            <div class="slice-slider-wrapper">
                <?php echo do_shortcode($content); ?>
            </div>
        </div>
    </div>
</div>