<?php
/*
 *
 *
 */

$image = $url = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
$image = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';
$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );

if(!empty($image)) { ?>
    <div class="col-xs-6 col-sm-3">
        <a href="<?php echo esc_url($url['url'])?>" class="client-logo mouseover-2"><img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_attr($url['title'])?>" /></a>
    </div>
<?php } ?>