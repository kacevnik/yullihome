<?php
/*
 *
 */
$css= '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

?>


<div class="swiper-entry <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="swiper-container" data-breakpoints="1" data-xs-slides="1" data-sm-slides="2" data-md-slides="2" data-lt-slides="3" data-slides-per-view="3" data-space="30">
        <div class="swiper-button-prev hidden"></div>
        <div class="swiper-button-next hidden"></div>
        <div class="swiper-wrapper">
            <?php print do_shortcode($content); ?>
        </div>
        <div class="swiper-pagination relative-pagination"></div>
    </div>
</div>
