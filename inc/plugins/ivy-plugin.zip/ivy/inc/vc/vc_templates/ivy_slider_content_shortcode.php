<?php
/*
 *
 *
 */

$image= $title= $text = $url = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);
$img = (is_numeric($image) && !empty($image)) ? wp_get_attachment_url($image) : '';

if(!empty($img)) { ?>
    <div class="swiper-slide">
        <div class="text-center">
            <img class="thumbnail-image col-xs-b20" src="<?php echo esc_url($img)?>" alt="" />
            <?php $title = !empty($title) ? $title : '';?>
            <?php $desc = !empty($desc) ? $desc : '';?>
            <h6 class="h6 col-xs-b10"><?php echo esc_html($title); ?></h6>
            <div class="sa middle"><?php echo do_shortcode($desc)?></div>
        </div>
    </div>
<?php } ?>
