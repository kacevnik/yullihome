<?php
/*
 *
 */
$css= '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

?>


<div class="swiper-entry slider-about <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="swiper-container" data-slides-per-view="1" data-initialslide="1" data-center="1" data-speed="1000">
        <div class="swiper-button-prev"></div>
        <div class="swiper-button-next"></div>
        <div class="swiper-wrapper">
            <?php print do_shortcode($content); ?>
        </div>
        <div class="swiper-pagination relative-pagination visible-xs visible-sm"></div>
    </div>
</div>