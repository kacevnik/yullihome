<?php
/*
 *
 */
$space = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$space = is_numeric($space) ? $space : '';

$space_sm = $space / 2; 
?>
 <div class="empty-space col-xs-b<?php echo $space_sm;?> col-sm-b<?php echo $space;?>"></div>