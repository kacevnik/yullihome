<?php
/*
 *
 */
$css = $position = $image = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);


$icon = (is_numeric($icon) && !empty($icon)) ? wp_get_attachment_url($icon) : '';
$top_text = !empty($top_text) ? $top_text : '';
$title = !empty($title) ? $title : '';
$desc = !empty($desc) ? $desc : '';


?>


<div class="services-shortcode-2 <?php echo apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts )?>">
    <div class="icon"><img src="<?php echo esc_url($icon); ?>" alt="<?php echo esc_attr($title); ?>" /></div>
    <div class="sl"><?php echo esc_html($top_text); ?></div>
    <div class="content">
        <div class="sa middle">
            <h6><?php echo esc_html($title); ?></h6>
            <?php echo do_shortcode($desc); ?>
        </div>
    </div>
</div>
