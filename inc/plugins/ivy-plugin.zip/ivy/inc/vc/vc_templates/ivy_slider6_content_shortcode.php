<?php
/*
 *
 *
 */

$image_left = $image_righ = $image_border = $title_hover = $text_top = $text_bottom = $url = '';

$atts = vc_map_get_attributes($this->getShortcode(), $atts);
extract($atts);

$image_left = (is_numeric($image_left) && !empty($image_left)) ? wp_get_attachment_url($image_left) : '';
$image_right = (is_numeric($image_right) && !empty($image_right)) ? wp_get_attachment_url($image_right) : '';
$image_border = (is_numeric($image_border) && !empty($image_border)) ? wp_get_attachment_url($image_border) : '';

$text_top = !empty($text_top) ? $text_top : '';
$text_bottom = !empty($text_bottom) ? $text_bottom : '';

$url = ( '||' === $url ) ? '' : $url;
$url = vc_build_link( $url );

?>


<div class="swiper-slide">
    <div class="container-fluid wide">
        <div class="background-entry left" data-swiper-parallax-y="-35%" style="background-image: url(<?php echo esc_url($image_left)?>);"></div>
        <div class="background-entry right" data-swiper-parallax-y="35%" style="background-image: url(<?php echo esc_url($image_right)?>);"></div>
        <div class="white-line"></div>
        <div class="full-size">
            <div class="background-frame border-image" style="border-image-source: url(<?php echo esc_url($image_border)?>);">
                <div class="content"></div>
                <div class="sl light"><?php echo esc_html($text_top); ?></div>
                <div class="sl light right"><?php echo esc_html($text_bottom); ?></div>
            </div>
        </div>
        <div class="title-wrapper valign-middle">
            <div class="content">
                <div class="h1 title light text-center"><span class="ht-2"><a href="<?php echo esc_url($url['url'])?>"><?php echo esc_html($url['title'])?></a></span></div>
            </div>
        </div>
    </div>
</div>