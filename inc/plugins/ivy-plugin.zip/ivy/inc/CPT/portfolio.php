<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.


/**
 * Register Post Type and Taxonomies
 *
 */
function portfolio_module_cpt() {

    /**
	 * Register Post Type
	 */

	// Arguments
	$cpt_args = array(
		'labels' => array(
			'name' => esc_attr__( 'Portfolio', 'ivy' ),
			'singular_name' => esc_attr__( 'Portfolio', 'ivy' ),
			'add_new' => esc_attr__( 'Add Portfolio', 'ivy' ),
			'add_new_item' => esc_attr__( 'Add Portfolio', 'ivy' ),
			'edit' => esc_attr__( 'Edit', 'ivy' ),
			'edit_item' => esc_attr__( 'Edit Portfolio', 'ivy' ),
			'new_item' => esc_attr__( 'New Portfolio', 'ivy' ),
			'view' => esc_attr__( 'View Portfolio', 'ivy' ),
			'view_item' => esc_attr__( 'View Portfolio', 'ivy' ),
			'search_items' => esc_attr__( 'Search Portfolio', 'ivy' ),
			'not_found' => esc_attr__( 'No Portfolio found', 'ivy' ),
			'not_found_in_trash' => esc_attr__( 'No Portfolio found in Trash', 'ivy' ),
			'parent' => esc_attr__( 'Parent Portfolio', 'ivy' ),
		),
		'has_archive'  => false,
		'public' => true,
		'rewrite' => true,
		'supports' => array( 'title', 'editor', 'thumbnail' ),
	);

	// Apply filters
	$cpt_args = apply_filters( 'portfolio_cpt_args', $cpt_args );

	// Register Post Type
	register_post_type( 'portfolio', $cpt_args );

	/**
	 * Register Taxonomy ( Category )
	 */

	// Arguments
	$tax_args = array(
		'labels' => array(
			'name' => esc_attr__( 'Portfolio Categories', 'ivy' ),
			'singular_name' => esc_attr__( 'Category', 'ivy' ),
			'search_items'  => esc_attr__( 'Search Categories', 'ivy' ),
			'all_items' => esc_attr__( 'All Categories', 'ivy' ),
			'parent_item' => esc_attr__( 'Parent Category', 'ivy' ),
			'parent_item_colon' => esc_attr__( 'Parent Category:', 'ivy' ),
			'edit_item' => esc_attr__( 'Edit Category', 'ivy' ),
			'update_item' => esc_attr__( 'Update Category', 'ivy' ),
			'add_new_item' => esc_attr__( 'Add New Category', 'ivy' ),
			'new_item_name' => esc_attr__( 'New Category Name', 'ivy' ),
			'menu_name' => esc_attr__( 'Categories', 'ivy' ),
		),
		'hierarchical' => true,
		'public' => true,
		'rewrite' => true,
	);

	// Apply filters
	$tax_args = apply_filters( 'portfolio_cats_args', $tax_args );

	// Register Taxonomy
	register_taxonomy( 'portfolio_cats', 'portfolio', $tax_args );

  //---Add models
        $labels = array(
            'name'              =>  esc_attr__( 'Tags', 'ivy' ),
            'singular_name'     =>  esc_attr__( 'Tag', 'ivy' ),
            'search_items'      => 	esc_attr__( 'Search', 'ivy' ),
            'all_items'         => 	esc_attr__( 'All tags', 'ivy' ),
            'edit_item'         => esc_attr__( 'Edit', 'ivy' ),
            'update_item'       => esc_attr__( 'Update', 'ivy' ),
            'add_new_item'      => esc_attr__( 'Add New', 'ivy' ),
            'new_item_name'     => esc_attr__( 'New Name', 'ivy' ),
            'menu_name'         => esc_attr__( 'Tags', 'ivy' ),
        );
        $args = array(
            'label'                 => '',
            'labels'                => $labels,
            'description'           => '',
            'public'                => true,
            'publicly_queryable'    => null,
            'show_in_nav_menus'     => true,
            'show_ui'               => true,
            'show_tagcloud'         => true,
            'hierarchical'          => false,
            'update_count_callback' => '',
            'rewrite'               => true,
            'show_admin_column'     => false,
            '_builtin'              => false,
            'show_in_quick_edit'    => null,
        );
        register_taxonomy('portfolio_tags', array('portfolio'), $args );

} add_action( 'init', 'portfolio_module_cpt',5 );
