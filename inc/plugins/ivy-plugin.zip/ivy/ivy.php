<?php
/*
Plugin Name: IVY Plugin
Plugin URI:
Author:
Author URI:
Version: 1.0
Description: Plugin needed for theme to work smoothly.
Text Domain: ivy
*/

// Define Constants
define('FW_ROOT', dirname(__FILE__));
define('FW_VERSION', '1.4');

require_once FW_ROOT . '/functions.php';

//Include Portfolio CPT

include FW_ROOT . '/inc/CPT/portfolio.php';


//Include Clients CPT

//Include redux framework
if ( ! class_exists( 'Redux'  ) ) {
	include FW_ROOT . '/inc/redux/admin-init.php';
}

//Include CS framework
if ( ! class_exists( 'CSFramework'  ) ) {
	include FW_ROOT . '/inc/cs-framework/cs-framework.php';
}

//Include VC stuff
	if ( function_exists( 'vc_set_as_theme' ) ) {
		include FW_ROOT . '/inc/vc/vc-init.php';
	}



/*-----------------------------------------------------------------------------------*/
/* Remove no-ttfmwrk class from body, when this plugin is active. */
/*-----------------------------------------------------------------------------------*/
add_filter( 'body_class','tempttfmwrk_yes', 11 );
if ( ! function_exists( 'tempttfmwrk_yes' ) ) {
function tempttfmwrk_yes( $classes ) {

	if (($key = array_search('no-ttfmwrk', $classes)) !== false) {
    unset($classes[$key]);
	}
	return $classes;
  }
}
