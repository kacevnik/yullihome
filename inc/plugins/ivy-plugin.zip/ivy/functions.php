<?php

include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(is_plugin_active('js_composer/js_composer.php')){
    function ivy_vc_multiselect() {
        function multiselect_param($settings, $value) {
            $css_option = vc_get_dropdown_option( $settings, $value );
            $value1 = explode( ',', $value );
            $output  = '<select name="'. $settings['param_name'] .'" data-placeholder="'. $settings['placeholder'] .'" multiple="multiple" class="wpb_vc_param_value wpb_chosen chosen wpb-input wpb-efa-select '. $settings['param_name'] .' '. $settings['type'] .' '. $css_option .'" data-option="'. $css_option .'">';
            foreach ( $settings['value'] as $values => $option ) {
                $selected = ( in_array( $option, $value1 ) ) ? ' selected="selected"' : '';
                $output .= '<option value="'. $option .'"'. $selected .'>'.htmlspecialchars( $values ).'</option>';
            }
            $output .= '</select>' . "\n";
            return $output;
        }
        vc_add_shortcode_param('ivy_vc_multiselect', 'multiselect_param');
    }
    add_action( 'vc_before_init', 'ivy_vc_multiselect' );
}

add_action('wp_footer','ivy_ajaxurl');
function ivy_ajaxurl() { ?>
    <script type="text/javascript">
        var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    </script>
    <?php
}


//Share
if ( ! function_exists( 'ivy_plugin_load_scripts' ) ) {
    function ivy_plugin_load_scripts() {

        if(is_single()){
            wp_enqueue_script( 'sharethis','http://w.sharethis.com/button/buttons.js',  '', null, true );
            wp_add_inline_script( 'sharethis', 'stLight.options({publisher: "cbf95bf6-a66c-4e9f-b681-eba65a73a3df", doNotHash: false, doNotCopy: false, hashAddressBar: false});' );
        }

    }
    add_action( 'wp_enqueue_scripts', 'ivy_plugin_load_scripts' );
}


//ajax login
add_action( 'wp_ajax_nopriv_ajaxlogin', 'ivy_ajax_login' );
function ivy_ajax_login(){
    check_ajax_referer( 'ajax-login-nonce', 'security' );
    $info = array();
    $info['user_login']    = ( $_POST['username'] ? $_POST['username'] : '' );
    $info['user_password'] = ( $_POST['password'] ? $_POST['password'] : '' );
    $info['remember']      = true;

    $user_signon = wp_signon( $info, false );
    if( is_wp_error( $user_signon ) ){ print json_encode( array( 'loggedin'=>false, 'message'=> esc_html__('Invalid login or password', 'ivy') ) ); }
    else{ print json_encode( array( 'loggedin'=>true, 'message'=> esc_html__('Password accepted. Redirecting ...', 'ivy') ) ); }

    die();
}

//new user registration
add_action('wp_ajax_register_user', 'ivy_reg_new_user');
add_action('wp_ajax_nopriv_register_user', 'ivy_reg_new_user');
function ivy_reg_new_user() {
    if( !isset( $_POST['nonce'] ) || !wp_verify_nonce( $_POST['nonce'], 'vb_new_user' ) )
        die();

    $name      = ( $_POST['name'] ? $_POST['name'] : '' );
    $email     = ( $_POST['mail'] ? $_POST['mail'] : '' );
    $password  = ( $_POST['pass'] ? $_POST['pass'] : '' );
    $password2 = ( $_POST['pass2'] ? $_POST['pass2'] : '' );
    $rules     = ( $_POST['rules'] ? $_POST['rules'] : '' );

    $userdata = array(
        'first_name' => $name,
        'user_login' => $name,
        'user_email' => $email,
        'user_pass'  => $password,
    );
    $creds                  = array();
    $creds['user_login']    = $name;
    $creds['user_password'] = $password;
    $creds['remember']      = true;

    //--IF RULES EMPTY--//
    if( $rules != '1' ){
        $json_reg['message'] = esc_html('Accept the rules of registration!', 'ivy');
        print json_encode( $json_reg );
        die();
    }
    //--Password--//
    if( isset( $password ) && $password != $password2 ){
        $json_reg['message'] = esc_html('Passwords do not match!', 'ivy');
        print json_encode( $json_reg );
        die();
    }
    //--Create new user--//
    $user_id = wp_insert_user( $userdata );
    if( !is_wp_error($user_id) && $userdata['first_name'] && $userdata['user_pass']) {
        update_user_meta( $user_id, 'rules', htmlentities( $rules ) );

        //--woocommerce--//
        update_user_meta( $user_id, 'billing_first_name', htmlentities( $name ) );
        update_user_meta( $user_id, 'billing_email', htmlentities( $email ) );

        wp_signon( $creds, false );
        $json_reg['status']      = '1';
        $json_reg['redirecturl'] = home_url("/").'my-account/';

        //--IF ERROR--//
        if( is_wp_error($user_id) ){
            $error = $user_id->get_error_codes();
            if(in_array('existing_user_email',$error)){ $json_reg['message'] = esc_html__('This email address is already registered!', 'ivy'); }
            elseif(in_array('existing_user_login',$error)){ $json_reg['message'] = esc_html__('This user name is already registered!', 'ivy'); }
        } else{
            $json_reg['message'] = esc_html__('Please fill in all fields!', 'ivy');
        }
    }

    print json_encode( $json_reg );
    die();
}




//REGISTER NEW POST TYPE
function portfolio_post_type()
{
    register_post_type(
        'portfolio',
        array(
            'labels'        => array(
                'name'               => esc_html__('Portfolio', 'ivy'),
                'singular_name'      => esc_html__('Portfolio', 'ivy'),
                'menu_name'          => esc_html__('Portfolio', 'ivy'),
                'name_admin_bar'     => esc_html__('Portfolio Item', 'ivy'),
                'all_items'          => esc_html__('All Items', 'ivy'),
                'add_new'            => _x('Add New', 'portfolio', 'ivy'),
                'add_new_item'       => esc_html__('Add New Item', 'ivy'),
                'edit_item'          => esc_html__('Edit Item', 'ivy'),
                'new_item'           => esc_html__('New Item', 'ivy'),
                'view_item'          => esc_html__('View Item', 'ivy'),
                'search_items'       => esc_html__('Search Items', 'ivy'),
                'not_found'          => esc_html__('No items found.', 'ivy'),
                'not_found_in_trash' => esc_html__('No items found in Trash.', 'ivy'),
                'parent_item_colon'  => esc_html__('Parent Items:', 'ivy'),
            ),
            'public'        => true,
            'menu_position' => 5,
            'supports'      => array(
                'title',
                'editor',
                'thumbnail',
                'excerpt',
                'custom-fields',
            ),
            'taxonomies'    => array(
                'portfolio_categories',
            ),
            'has_archive'   => true,
            'rewrite'       => array(
                'slug' => 'portfolio',
            ),
        )
    );
}


//REGISTER TAXONOMY
function ivy_register_taxonomy()
{
    register_taxonomy(
        'portfolio_categories',
        array(
            'portfolio',
        ),
        array(
            'labels'            => array(
                'name'              => _x('Categories', 'portfolio', 'ivy'),
                'singular_name'     => _x('Category', 'portfolio', 'ivy'),
                'menu_name'         => esc_html__('Categories', 'ivy'),
                'all_items'         => esc_html__('All Categories', 'ivy'),
                'edit_item'         => esc_html__('Edit Category', 'ivy'),
                'view_item'         => esc_html__('View Category', 'ivy'),
                'update_item'       => esc_html__('Update Category', 'ivy'),
                'add_new_item'      => esc_html__('Add New Category', 'ivy'),
                'new_item_name'     => esc_html__('New Category Name', 'ivy'),
                'parent_item'       => esc_html__('Parent Category', 'ivy'),
                'parent_item_colon' => esc_html__('Parent Category:', 'ivy'),
                'search_items'      => esc_html__('Search Categories', 'ivy'),
            ),
            'show_admin_column' => true,
            'hierarchical'      => true,
            'rewrite'           => array(
                'slug' => 'portfolio/category',
            ),
        )
    );
}

function register_post() {
    add_action('init', 'ivy_post_type');
    add_action('init', 'ivy_register_taxonomy', 0);
}
add_action( 'init', 'register_post' );
